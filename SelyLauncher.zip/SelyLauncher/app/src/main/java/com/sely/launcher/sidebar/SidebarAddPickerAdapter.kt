package com.sely.launcher.sidebar

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppInfo
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

/**
 * Click-to-add list for Smart Sidebar's "+ Add" favorites picker.
 * Deliberately separate from AppGridAdapter: that adapter's tap
 * action launches the app, which is the opposite of what tapping
 * should do here (add it as a favorite, not open it).
 */
class SidebarAddPickerAdapter(
    private val context: Context,
    private val apps: List<AppInfo>,
    private val onPicked: (AppInfo) -> Unit
) : RecyclerView.Adapter<SidebarAddPickerAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.icon.background = null
        holder.label.text = app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.itemView.setOnClickListener { onPicked(app) }
    }
}
